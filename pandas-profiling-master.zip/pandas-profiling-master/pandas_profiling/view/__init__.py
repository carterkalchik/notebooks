"""All functionality concerned with presentation to the user."""
